export declare class MitraModule {
}
