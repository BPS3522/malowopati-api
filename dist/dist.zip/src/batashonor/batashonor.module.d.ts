export declare class BatashonorModule {
}
