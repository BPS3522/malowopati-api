"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatashonorModule = void 0;
const common_1 = require("@nestjs/common");
const batashonor_controller_1 = require("./batashonor.controller");
const batashonor_service_1 = require("./batashonor.service");
const core_1 = require("@nestjs/core");
const auth_guard_1 = require("../auth/auth.guard");
let BatashonorModule = class BatashonorModule {
};
exports.BatashonorModule = BatashonorModule;
exports.BatashonorModule = BatashonorModule = __decorate([
    (0, common_1.Module)({
        controllers: [batashonor_controller_1.BatashonorController],
        providers: [
            batashonor_service_1.BatashonorService,
            {
                provide: core_1.APP_GUARD,
                useClass: auth_guard_1.AuthGuard,
            },
        ]
    })
], BatashonorModule);
//# sourceMappingURL=batashonor.module.js.map