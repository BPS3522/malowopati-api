export declare class HonormitraModule {
}
