export declare class KegiatanModule {
}
