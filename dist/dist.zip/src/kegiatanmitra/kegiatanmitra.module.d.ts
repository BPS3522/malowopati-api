export declare class KegiatanmitraModule {
}
